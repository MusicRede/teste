const router = require("express").Router();
const Discord = require("discord.js");
const fetch = require("node-fetch");
const btoa = require("btoa");
const bt = require("btoa");
const request = require("request");
const fetchUserInfo = require("../util.js").fetchUserInfo;
const CLIENT_TOKEN = process.env.TOKEN;
const CLIENT_SECRET = process.env.SECRET;
const Database = require("../database.js");
const mongoose = require("mongoose");
const client = new Discord.Client();
const path = require("path");
const express = require("express");
const app = express();
const server = require("http").createServer(app);
const io = require("socket.io")(server);
let messages = []
const { redirect_uri, id, secret } = require("../config.json");
let morty = 1;
let rolear = [],guildaar = []
client.login(CLIENT_TOKEN);
router.get("/", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  res.render("index", { client, user });
  //console.log("ok")
  //client.channels.get('666995196797648918').send(`${req.session.user.username} Logou no Site`)
});
router.get("/usuarios", async (req, res) => {
  let array = [];
  let teste = [];
  let level = [];
  let XP = [];
  let idlogado = [];
  let id = [];
  let banco = [];
  let dinheiro = [];
  const user = await fetchUserInfo(req.cookies);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
  client.users.map(x => {
    //console.log(x.id)
    Database.Usuarios.findOne({ _id: x.id }, function(erro, dados) {
      if (dados) {
        //console.log(dados)
        morty++;
        teste[morty] = dados.nome;
        level[morty] = dados.level;
        XP[morty] = dados.xp;
        idlogado[morty] = dados.idlogado;
        id[morty] = dados._id;
        dinheiro[morty] = dados.dinheiro;
        banco[morty] = dados.banco;
        //console.log(`${dados.banco}` + `Var ${dinheiro[morty]}`)
        //console.log(teste[morty])
      }
    });
  });
  setTimeout(function() {
    res.render("usuarios.ejs", {
      client,
      user,
      Database,
      morty: morty,
      teste: teste,
      level: level,
      xp: XP,
      idlogado: idlogado,
      id: id,
      banco: banco,
      dinheiro: dinheiro
    });
  }, 3000);
  morty = 0;
});
router.get("/suporte", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  res.render("suporte.ejs", {
    user,
    client,
    Database
  });
});
router.get("/comandos", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  res.render("comandos.ejs", { user, client });
});
router.get("/dashboard", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  if (!user)
    return res.redirect(
      "https://discordapp.com/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Fcallback&response_type=code&scope=identify%20email%20guilds%20connections"
    );
  Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
    res.render("dashboard.ejs", {
      user,
      client,
      Database,
      acesso: valor.acesso
    });
  });
});
router.get("/config/:id/roles", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  var id = req.params.id,cont,idr = [],nome = [],cor = [];
  let guilda = client.guilds.get(id);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
    Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
    guilda.roles.map(role => {
    cont++;
    idr[cont] = role.id;
    nome[cont] = role.name
    cor[cont] = role.color
    })
    res.render("roles.ejs", {
      user,
      client,
      Database,
      guilda,
      acesso: valor.acesso,idr: idr,cont,nome: nome,cor: cor
    });
  });
  cont = 0;
});
router.get("/config/:id/cargo/:role", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  var id = req.params.id;
  var role = req.params.role;
  //console.log(id)
 // console.log(role)
  let guilda = client.guilds.get(id);  
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
      Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
      rolear.push(role)
      guildaar.push(id)
      res.render("cargo.ejs", {
      user,
      client,
      Database,
      guilda,
      acesso: valor.acesso,role: guilda.roles.get(role),roleID:role,guilda
    });
  });
});
router.get("/config/:id/acesso", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  var id = req.params.id;
  let guilda = client.guilds.get(id);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
  client.guilds.get(guilda.id).channels.map(value =>{
    let permissao = value.overwritePermissions("336905723621670914", {
    'VIEW_CHANNEL': true ,
    'SEND_MESSAGES': true
})
  })
  Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
    res.render("acesso.ejs", {
      user,
      client,
      Database,
      guilda,
      acesso: valor.acesso
    });
  });
});
router.get("/config/:id/admin", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  let array = [];
  let teste = [];
  let level = [];
  let XP = [];
  let idlogado = [];
  let idx = [];
  let banco = [];
  let dinheiro = [];
  var id = req.params.id;
  let guilda = client.guilds.get(id);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
  client.users.map(x => {
    //console.log(x.id)
    Database.Usuarios.findOne({ _id: x.id }, function(erro, dados) {
      if (dados) {
        morty++;
        teste[morty] = dados.nome;
        level[morty] = dados.level;
        XP[morty] = dados.xp;
        idlogado[morty] = dados.idlogado;
        idx[morty] = dados._id;
        dinheiro[morty] = dados.dinheiro;
        banco[morty] = dados.banco;
      }
    });
  });
  Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
    setTimeout(function() {
      res.render("admin.ejs", {
        user,
        client,
        Database,
        guilda,
        acesso: valor.acesso,
        morty: morty,
        teste: teste,
        level: level,
        xp: XP,
        idlogado: idlogado,
        id: id,
        banco: banco,
        dinheiro: dinheiro
      });
    }, 1000);
  });
  morty = 0;
});
router.get("/config/:id/conta", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  var id = req.params.id;
  let guilda = client.guilds.get(id);
  Database.Usuarios.findOne({ _id: user.id }, function(erro, valor) {
    let perm = valor.acesso,
      nome;
    if (perm == "1") {
      nome = "Administrador";
    } else {
      nome = "Usuario";
    }
    res.render("conta.ejs", {
      user,
      client,
      Database,
      guilda,
      level: valor.level,
      banco: valor.banco,
      xp: valor.xp,
      dinheiro: valor.dinheiro,
      permissao: nome,
      acesso: valor.acesso
    });
  });
});
router.get("/sobre", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  res.render("sobre.ejs", {
    user,
    client
  });
});
router.get("/servidores", async (req, res) => {
  // console.log("1")
  let nome = [];
  let id = [];
  let prefixo = [];
  const user = await fetchUserInfo(req.cookies);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
    client.guilds.forEach(x => {
      Database.Guilds.findOne({ _id: x.id }, function(erro, valor) {
        if(valor) {
        let arra = valor.autorizados   
       // console.log(x.name)
       // console.log(x.id)
        if(x.members.get(user.id))
        {          
        if(x.ownerID == user.id)
        {
        morty++;          
        console.log(`${user.username} É Dono do servidor ${x.name}`)
        nome[morty] = client.guilds.get(x.id).name;id[morty] = valor._id;
        prefixo[morty] = client.users.get(x.ownerID).username; 
        }   
        else if(arra.indexOf(user.id) > -1)
        {    
        morty++;
        console.log(`${user.username} está na array da Guilda ${x.name} | Array ${arra} Numero: ${morty}`)
        nome[morty] = client.guilds.get(x.id).name;id[morty] = valor._id;    
        prefixo[morty] = client.users.get(x.ownerID).username;       
        //let servidor = client.guilds.get("671385571561570327");
       // let membro = servidor.members.get("665200472596152341");          
        //if(membro.roles.find(r => r.id == "671385666524807178")) return console.log("é criador do Smash")        
        }           
        }
      }        
    });
  });
  setTimeout(function() {
    res.render("servidores.ejs", {
      user,
      client,
      Database,
      nome: nome,
      id: id,
      prefixo: prefixo,
      morty: morty
    });
  }, 2000);
  morty = 0;
});
router.get("deletar", (req, res) => {
  console.log("deletou");
});
router.get("/login", (req, res) => {
  res.redirect(
    "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2F&response_type=code&scope=identify%20email%20guilds%20connections"
  );
});
router.get("/callback", async (req, res) => {
  if (!req.query.code) throw new Error("NoCodeProvided");
  const code = req.query.code;
  const creds = btoa(`671049490349686825:${CLIENT_SECRET}`);
  const response = await fetch(
    `https://discordapp.com/api/oauth2/token?grant_type=authorization_code&code=${code}&redirect_uri=https://smoke-discord-bot.glitch.me/callback`,
    {
      method: "POST",
      headers: {
        Authorization: `Basic ${creds}`
      }
    }
  );
  const json = await response.json();
  await res.cookie("userToken", json.access_token);
  await res.cookie("userRefreshToken", json.refresh_token);

  setTimeout(() => {
    res.redirect("/");
  }, 1000);

  const user = await fetchUserInfo({
    userToken: json.access_token,
    userRefreshToken: json.refresh_token
  });

  console.log(user);

  //client.channels.get('625372229441552394').send(user.username + "#" + user.discriminator + " logou no site!!")
});
router.get("/logout", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  //client.channels.get('673542633402138644').send(user.username + "#" + user.discriminator + " deslogou do site!!")
  res.cookie("userToken", null);
  res.cookie("userRefreshToken", null);
  res.redirect("/");
});
router.get("/dashboard", async (req, res) => {
  const user = await fetchUserInfo(req.cookies);
  res.render("dashboard", { user, client });
});
router.post("/registro", async (req, res) => {
  let aviso = 0;
  const { nome, id, senha } = req.body;
  //if(nome.length <= 4 || senha.length <= 4) return res.end("Nome ou Senha devem possuir mais de 4 Caracters")
  client.users.forEach(x => {
    if (x.id == id) return (aviso = 1);
  });
  if (aviso == 0) return res.end("Não tenho esse ID No Discord");
  //console.log(`Nome: ${nome} ID: ${id} Senha: ${senha}`)
  const data = await Database.Usuarios.findOne({ _id: id });
  if (!data) {
    new Database.Usuarios({
      _id: id,
      nome: nome,
      senha: senha,
      xp: "0",
      level: "0",
      logado: true
    }).save();
    return res.end(
      `Usuario Cadastrado com Sucesso! Nome: ${nome} Senha: ${senha} ID: ${id}`
    );
  } else {
    res.end("Esse ID Já está Registrado");
  }
});
router.post("/economia", async (req, res) => {
  // let aviso = 0;
  const { dinheiro, id, banco } = req.body;
  //if(nome.length <= 4 || senha.length <= 4) return res.end("Nome ou Senha devem possuir mais de 4 Caracters")
  // const data = await Database.Usuarios.findOne({_id:id})
  // if(data)
  //   {
  Swal.fire({
    position: "top-end",
    icon: "success",
    title: "Your work has been saved",
    showConfirmButton: false,
    timer: 1500
  });
  //data.banco = banco;
  //data.dinheiro = dinheiro;
  //data.save();
  //   }
  // else
  //{
  //  res.end("Esse ID Não está cadastrado no meu Banco de Dados")
  //  }
});
router.post("/mudars", async (req, res) => {
  let aviso = 0;
  const { ida, nsenha, motivo } = req.body;
  //if(nome.length <= 4 || senha.length <= 4) return res.end("Nome ou Senha devem possuir mais de 4 Caracters")
  const data = await Database.Usuarios.findOne({ _id: ida });
  if (data) {
    res.end(`Senha do Usuario ID: ${ida} Alterado para ${nsenha}`);
    client.channels
      .get("671385571561570333")
      .send(
        `[ SITE ] Senha do Usuario ID: ${ida} Alterada para ${nsenha} Motivo: ${motivo}`
      );
    data.senha = nsenha;
    data.idlogado = 0;
    data.save();
  } else {
    res.end("Esse ID Não está cadastrado no meu Banco de Dados");
  }
});
router.get("/keys", async (req, res) => {
  // console.log("1")
  let key = [];
  let max_usos = [];
  let prefixo = [];
  const user = await fetchUserInfo(req.cookies);
  if (!user)
    return res.redirect(
      "https://discordapp.com/api/oauth2/authorize?client_id=671049490349686825&redirect_uri=https%3A%2F%2Fsmoke-discord-bot.glitch.me%2Flog&response_type=code&scope=identify%20guilds%20connections%20email"
    );
  client.guilds.map(x => {
    //   console.log("2")
    let data = Database.Keys;
    if (data) {
      //console.log("3")
      morty++;
      key[morty] = data.key;
      max_usos[morty] = data.max_usos;
    }
  });
  setTimeout(function() {
    res.render("servidores.ejs", {
      user,
      client,
      Database,
      key: key,
      max_usos: max_usos,
      morty: morty
    });
  }, 3000);
  morty = 0;
});
module.exports = router;
/*
app.use(express.static(path.join(__dirname, 'public')));
app.set('views',path.join(__dirname,"public"));
app.engine("views",require("ejs").renderFile);
//app.set('view engine','html');
*/
router.get("/config/:id", async (req, res) => {
  var id = req.params.id;
  const user = await fetchUserInfo(req.cookies);
  let guilda = client.guilds.get(id);
  Database.Guilds.findOne({ _id: id }, function(erro, guild) {
    if (guild) {
      Database.Usuarios.findOne({_id:user.id}, function(erro, valor) {
        res.render("dashboard.ejs", {
          user,
          client,
          guilda,
          prefixo: guild.prefix,
          acesso: valor.acesso
        });
      });
    }
  });
});
router.post("/mudar/:morty/:rol",function(req,res){
  const {cor,role,guilda} = req.body  
  var idx = req.params.morty;
  var idy = req.params.rol;
 // console.log(`${idx} - ${idy}`)
  console.log(cor)
  client.guilds.get(idx).roles.get(idy).setColor(cor)
})

io.on('connection',socket => {
console.log(`Socket Conectado: ${socket.id}`)
})

        //if (membro.roles.has(cargo)) return console.log("sim")
        // membro.addRole(cargo)
        //else if(!membro.roles.has(cargo))return console.log("nao")
        //membro.roles.find(r => console.log(r.name))    